clear all
close all

%%

N = 20; 
[y, D, DD] = getdiffmatrices(N);

%% 

h   = 1; 
Pl  = 3; 
rho = 1; 
mu  = 1;
nu  = mu/rho; 
params.Pl  = Pl;
params.rho = rho;
params.mu  = mu;
params.nu  = nu;

u0 = zeros(N,1);
tf = 8; 
tspan = [0 tf];
ns   = 10;                  % number of snapshots
tout = linspace(0, tf, ns); % desired plotting times (uncomment corresponding line in odeset(...) )

M      = eye(N); 
M(1,1) = 0; 
M(N,N) = 0;

options = odeset('Mass',M, ...
                 'AbsTol',1e-6, ...
                 'RelTol',1e-5);
%                 'OutputFcn', @(t,u,flag) plot_u_profile(t,u,flag,y,tout));

sol = ode23t(@(t,u) eqns(t,u, D, DD, params), tspan, u0, options);

t = sol.x;
u = sol.y;
ucenter = u(1,:);

%%

an   = @(n,t) 16*Pl*h^2/(mu*pi^3*(2*n+1)^3)*(-1)^n*exp(-(2*n+1)^2*pi^2*nu/4*h^2*t);
sum  = an(0,t) + an(1,t);
uan0 = Pl/(2*mu)*(h^2  - 0^2) - sum;  
ts   = pi^2*nu/(4*h^2); 

%%

figure(166); hold on 

plot(t, uan0,'--k');  
plot(t, ucenter,'or');
hl = legend('MOL solution','Analytical solution');
set(hl, 'box','off')
xlabel $t$
ylabel $u_{y=0}$
line([ts ts],[0 Pl*h^2/(2*mu)],'linestyle','--','color',[0.2 0.5 0.5], 'HandleVisibility','off')
text(ts*1.05, Pl*h^2/(4*mu), "$t \simeq t_s$",'FontSize',16)

%%

print('./poiseuille_startup','-dpng','-r300')