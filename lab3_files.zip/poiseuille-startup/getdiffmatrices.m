function [y,Dy,Dyy] = getdiffmatrices(N)

[xi,DM] = chebdif(N,2);

D1 = DM(:,:,1); 
D2 = DM(:,:,2);

y = 1 - 1/2*(1+xi);

dxidy = -2; 
Dy    = dxidy  *D1;
Dyy   = dxidy^2*D2;

end