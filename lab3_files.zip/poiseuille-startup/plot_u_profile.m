function status = plot_u_profile(t,u,flag,y,tout)
% THIS FUNCTION HAS BEEN CREATED BY CHATGPT. IT CREATES A NON-NEGLIGIBLE
% OVERHEAD, USE IT ONLY FOR DEBUGGING
% PLOT_U_PROFILE_SNAPSHOTS
%   OutputFcn for ode23t: plots y vs u(y,t) only at specified times TOUT.
%
%   Called by ODE suite via:
%       status = plot_u_profile_snapshots(t,u,flag,y,tout)
%
%   INPUTS (from ODE solver):
%       t    : time values since last call (vector, growing)
%       u    : solution values at those times (size N x length(t))
%       flag : 'init', '', or 'done'
%
%   EXTRA INPUTS:
%       y    : spatial grid (size N x 1)
%       tout : vector of desired snapshot times
%
%   The function keeps track of the next snapshot time with a persistent
%   index and plots only when t crosses tout(k).

    persistent hFig k

    switch flag
        case 'init'
            % Initialization at start of integration
            k    = 1;     % index into snapshot times
            hFig = figure(100); clf
            % Optional: initial plot at t = t(1)
            u_now = u(:,1);
            plot(u_now, y, '-o');
            set(gca,'YDir','normal');  % y increasing upwards
            xlabel('u(y,t)')
            ylabel('y')
            title(sprintf('t = %.3f', t(1)));
            drawnow

        case ''
            % Called after each successful internal step.
            % t and u can both be vectors (multiple steps since last call).

            if isempty(hFig) || ~ishandle(hFig)
                hFig = figure(100); clf
            else
                figure(hFig);
            end

            % Loop over all newly provided times
            for j = 1:length(t)
                % While we still have snapshot times left
                % and current solver time has reached or passed tout(k)
                while (k <= numel(tout)) && (t(j) >= tout(k))
                    u_now = u(:,j);   % solution at current time
                    plot(u_now, y, '-o');
                    set(gca,'YDir','normal');
                    xlabel('u(y,t)')
                    ylabel('y')
                    title(sprintf('t = %.3f (snapshot %d/%d)', t(j), k, numel(tout)));
                    drawnow;

                    k = k + 1;       % move to next snapshot time
                end
            end

        case 'done'
            % Clean up at the end of integration if you like
            % clear hFig k  % uncomment if you want to reset between runs
    end

    status = 0;  % return 1 to stop the integration
end
