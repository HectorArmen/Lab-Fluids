function dudt = eqns(t, u, D, DD, params)

N = length(u);

Pl   = params.Pl;
nu   = params.nu;
rho  = params.rho;
mu   = params.mu;

dudt = Pl*ones(N,1)/rho + nu*DD*u; % Eqns at 0 < y < 1

% Now override DOFS at y = 0 and y = 1

dudt(1) = D(1,:)*u; % Symmetry
dudt(N) = u(N) - 0; % No slip

end