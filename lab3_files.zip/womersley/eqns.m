function ut = eqns(u,t,D,DD,Wo)

N  = length(u);

% Define the evolution problem:

ut = Pl(t)*ones(N,1) + 1/Wo*DD*u; 

% Boundary conditions at y = 0 and y = 1:

ut(1) = u(1) - 0.0; % y=0 -> u = 0;
ut(1) = D(1,:)*u;   % y=0 -> du/dy =0;

ut(N) = u(N) - 0.0;

end