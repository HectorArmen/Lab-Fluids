function pl = Pl(t)

pl = sin(t);

end