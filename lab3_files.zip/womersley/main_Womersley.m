close all
clear all

%%

Wov = [1 10 100 1000];

N  = 150;
tf = 20*pi;
NT = 200;

[y,D,DD] = getdiffmatrices(N);

% Initial condition:

u0 = zeros(size(y));

tspan = linspace(0,tf,NT);

% Mass matrix for those dofs where BCs are prescribed:

M = eye(N);

M(1,1) = 0;
M(N,N) = 0;

options = odeset('Mass',M,'AbsTol',1e-6,'RelTol',1e-4);

for nn = 1:length(Wov)

    Wo = Wov(nn);

    tic
    [time,usol] = ode23t(@(t,u) eqns(u,t,D,DD,Wo), tspan, u0, options);
    toc
    usol = usol';

    q = trapz(y,usol);

    tplot = 0:pi/4:6*pi;

    uq = interp1(time, usol', tplot);
    uq = uq';

    cmap = cmocean('balance',length(tplot));

    subplot(length(Wov)+1,1,nn)
    hold on 

    for jj = 1:length(tplot)

        plot(uq(:,jj) +  tplot(jj) ,y,'Color',cmap(jj,:))
        % hl{jj} = ['$t/\pi = ',num2str(tplot(jj)/pi),'$'];
        h1 = gca;
        h1.XAxis.Visible = 'off';
        axis tight
        
    end

    title(['$W\!o = ',num2str(Wov(nn)),'$'],'FontSize',10)

    xlabel $u$
    ylabel('$y$','Rotation',0)
    % legend(hl,'Interpreter','latex','box','off')

end

%%

subplot(length(Wov)+1,1,nn+1); hold on 
tp = linspace(tplot(1),tplot(end),100);
plot(tp, Pl(tp),'LineWidth',1.25)
plot(tplot,Pl(tplot),'o','LineWidth',1.6)
xlabel $t$
ylabel('$P_l(t)$','Rotation',0)

%%

print('./vel_profiles_plsint','-dpng','-r600')
