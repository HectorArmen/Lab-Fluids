close all
clear all

N = 50; 
[y, Dy, Dyy] = getdiffmatrices(N);

%%

Wo = 10; 
u0 = zeros(N,1);
tf = 5*pi;
tspan = [0 tf];

M = eye(N);
M(1,1) = 0; 
M(N,N) = 0;

options = odeset('Mass',M,'AbsTol',1e-6,'RelTol',1e-4);

sol = ode23t(@(t,u) eqns(u,t,Dy,Dyy, Wo), tspan, u0,options);

t = sol.x; 
u = sol.y;

figure(1);

for jj = 1:length(t)

    plot(u(:,jj), y); 
    xlim([min(min(u)), max(max(u))]);
    drawnow

end
