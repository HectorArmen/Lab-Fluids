function status = myfun(t,h,flag,x)

figure(1086);
plot(x,h);
title(num2str(t));
drawnow

status =0;

end