function [y,Dy,Dyy] = getdiffmatrices(N, ymax)

[s,DM] = chebdif(N,2);

D1 = DM(:,:,1); 
D2 = DM(:,:,2);

y = ymax/2*(1-s);

dsdy = -2/ymax; 
Dy   = dsdy  *D1;
Dyy  = dsdy^2*D2;

end