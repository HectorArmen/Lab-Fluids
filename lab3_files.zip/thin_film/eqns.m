function ht = eqns(t,h,D,DD,Ca,hprec)

% N = length(h);

M = h.^3/3;

phi = 1./h.^3 - hprec^6./h.^9;
p   = - DD*h/Ca + phi;
ht  = D*(M.*D*p);

% Boundary Conditions @x=0:

ht(1) = h(1) - hprec;         % Dirichlet
ht(2) = D(1,:)*h - 0.0;       % Homogeneous Neumann

% Boundary Conditions @x=xmax:

ht(end)   = h(end) - 1.0;
ht(end-1) = D(end-1,:)*h - 0.0;


end
