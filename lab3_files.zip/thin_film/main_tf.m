close all
clear all

%%

Ca    = 1;
hprec = 0.2;

N       = 280;
tf      = 0.5;
epsilon = 0.1;

k    = sqrt(3*Ca/2);
xmax = 3*pi/k;

[x,D,DD] = getdiffmatrices(N, xmax);

% ICs (note that y is a column vector):

h0 = (1+hprec)/2 + (1-hprec)/2*tanh(10*(x-xmax/5));

%%

tspan = [0 tf];

% (Singular) Mass matrix for those dofs where BCs are prescribed.

M          = eye(N, N);
M(1,1)     = 0;
M(2,2)     = 0;
M(N,N)     = 0;
M(N-1,N-1) = 0;

% options = odeset('Mass',M,'AbsTol',1e-4,'RelTol',1e-2,'OutputFcn',@(t,h,flag) myfun(t,h,flag,x));
options = odeset('Mass',M,'MassSingular','yes','AbsTol',1e-6,'RelTol',1e-4);

tic
[time, hsol] = ode23t(@(t,h) eqns(t,h,D,DD,Ca,hprec), tspan, h0, options);
toc

hsol = hsol';

%%

NTP   = 20;
tplot = linspace(0,tf*4/5,NTP);
hq    = interp1(time, hsol', tplot); hq = hq';

figure(1962); hold on 

cmap = cmocean('ice',NTP + 2);

for jj = 1:length(tplot)
    plot(x, hq(:,jj) + 10*tplot(jj), 'color',cmap(jj,:))   
end

hh = gca;
hh.YAxis.Visible = 'off';
hh.TickDir = 'out';
xlabel $x$
axis tight

%%

ylim([0 6])
print('./film_evol_Ca1_hprec0.1.png','-dpng','-r300')