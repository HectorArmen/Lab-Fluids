function [x,Dx,Dxx] = getdiffmatrices(N, xmax)

[s,DM] = chebdif(N,2);

D1 = DM(:,:,1); 
D2 = DM(:,:,2);

x = xmax*(1-s)-xmax;

dsdx = -1/xmax; 
Dx   = dsdx  *D1;
Dxx  = dsdx^2*D2;

end