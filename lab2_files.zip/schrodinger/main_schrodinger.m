h = 0.1; 
L = 3; 
N = 20;
I = eye(N);

[x,D,DD] = getdiffmatrices(N,L);
V = x.^2;

A = -h^2*DD + diag(V);
B =  I;

A(1,:) = 0; 
A(N,:) = 0;
A(1,1) = 1; 
A(N,N) = 1; 

B(1,:) = 0; 
B(N,:) = 0;

NE = 10;

[v,d] = eigs(A,B,NE,0);

lam = diag(d);

%%

figure(3063); hold on 

cmap = cmocean('-amp',NE+2);

for jj = 1:NE
    ue = v(:,jj);
    plot(x, ue+ lam(jj),'color',cmap(jj,:));
end

plot(x,V,'--k','LineWidth',2)
ylim([0 2.2]);
xlim([-3 3]);

xlabel $x$
ylabel('$u_n(x) + \lambda_n$','Rotation',0)

yticks(lam)

%%

print('./sol_schrodinger_Vx2','-dpng','-r600')