close all
clear all

%%

kv = linspace(1,5,50);
N  = 100;
mu = 1;
Ta_guess = 6e3;

%%

[y,D,DD] = getdiffmatrices(N);

I = eye(N);


for jj = 1:length(kv)

    k = kv(jj);

    A = (DD - k^2*I)^3;
    B = -k^2*diag(1-(1-mu)*y);

    % Kill dofs associated to u_{1,2,3} and u_{N-2,N-1,N}:

    A(1,:) = 0;
    A(2,:) = 0;
    A(3,:) = 0;
    B(1,:) = 0;
    B(2,:) = 0;
    B(3,:) = 0;

    A(N-2,:) = 0;
    A(N-1,:) = 0;
    A(N  ,:) = 0;
    B(N-2,:) = 0;
    B(N-1,:) = 0;
    B(N  ,:) = 0;

    % Dirichlet BCs:

    A(1,1) = 1;
    % B(1,1) = 0;
    A(N,N) = 1;
    % B(N,N) = 0;

    % Mixed BCs:

    Daux1   = DD - k^2*I;
    Daux2   = D*(DD-k^2*I);

    A(2,  :) = Daux1(2,:);
    A(3,  :) = Daux2(3,:);
    A(N-1,:) = Daux1(N-1,:);
    A(N-2,:) = Daux2(N-2,:);

    NE = 1;

    [v,Ta(jj)] = eigs(A,B,NE,Ta_guess);

    Ta_guess = Ta(jj);


end

figure(1669); hold on
plot(kv,Ta,'k')
[Tac,pos] = min(Ta);
kc = kv(pos);
plot(kc,Tac,'.r','MarkerSize',18)

xlabel $k$
ylabel('$T\!a$','Rotation',0);

text(kc,Tac*0.925,['$k_c =',num2str(kc),', Ta_c = ',num2str(Tac),'$'],'fontsize',14)

print('./Ta_vs_mu_k','-dpng','-r600')


%%

% figure(1626268); hold on
%
% plot(muv, Tac)
% xlabel('$\mu$')
% ylabel('$T\!a$','Rotation',0)
%
% % print('./Ta_c','-dpng','-r600')